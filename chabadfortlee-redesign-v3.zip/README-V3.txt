CHABAD OF FORT LEE — V3 DEPLOYMENT

Upload these 5 files individually to the ROOT of yysirota/customheader:
  site-redesign-v3.css
  site-redesign-v3.js
  cfle-hero-v3-desktop.webp
  cfle-hero-v3-mobile.webp
  cfle-mailing-bokeh-v3.webp

IMPORTANT: GitHub filenames must match exactly — no [1] in the names.

After GitHub Pages deploys, test these URLs directly:
  https://yysirota.github.io/customheader/site-redesign-v3.css
  https://yysirota.github.io/customheader/site-redesign-v3.js
  https://yysirota.github.io/customheader/cfle-hero-v3-desktop.webp
  https://yysirota.github.io/customheader/cfle-hero-v3-mobile.webp
  https://yysirota.github.io/customheader/cfle-mailing-bokeh-v3.webp

Only after all five URLs work, replace the ChabadOne Custom Header loader
with chabadone-loader-v3.html.

ROLLBACK:
If anything is wrong, replace the ChabadOne Custom Header immediately with
chabadone-loader-working-rollback.html. No GitHub deletion is necessary.

FUNCTIONALITY PRESERVED:
- existing custom-header.css / custom-header.js remain loaded
- existing chabad-events1/events.css / events.js remain loaded
- events widget is MOVED, not rebuilt
- Prayer Times widget is MOVED, not replaced
- Shabbat & Holidays widget is MOVED, not replaced
- mailing-list form is MOVED, not replaced
- Donate/menu/Pushka remain owned by existing custom-header code
